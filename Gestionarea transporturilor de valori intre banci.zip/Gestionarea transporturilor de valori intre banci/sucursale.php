


<?php

$conn=oci_connect("transport2","transport","//localhost/orcl");
   
$query = 'select *from sucursale ';
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);
$results = array();
$buffer= [];
while($buffer = oci_fetch_array ($stid, OCI_RETURN_NULLS+OCI_ASSOC)){
	$results[] = $buffer;
}

oci_close($conn);
?>

<html>

<head><title>TABEL SUCURSALE</title></head>
<style type="text/css">
table{
	border-collapse: collapse;
	width: 100%;
	color: #FF69B4;
	font-family: monospace;
	font-size: 25px;
	text-align: left;

	box-shadow: 0px 10px 50px -20px black;
    transform: scale(0.9);
	}

th{
	background-color: #DDA0DD;
	color: #4B0082;
	}
tr:nth-child(even){background-color: #F8F8FF}
</style>
<body>

 <!--   
// Fetch each row in an associative array
print '<table border="1">';
print'<tr><th><a href ="sucursale_id.php?">Ascendent</a></th><th><a href="sucursale_idc.php?">Ascendent</a></th><th><a href ="sucursale_idr.php?">Ascendent</a></th><th><a href ="sucursale_adresa.php?">Ascendent</a></th><th><a href ="sucursale_telefon.php?">Ascendent</a></th></tr>';
print'<tr><th><a href ="sucursale2_id.php?">Descendent</a></th><th><a href="sucursale2_idc.php?">Descendent</a></th><th><a href ="sucursale2_idr.php?">Descendent</a></th><th><a href ="sucursale2_adresa.php?">Descendent</a></th><th><a href ="sucursale2_telefon.php?">Descendent</a></th></tr>';
print"<tr><th>Id Sucursala</th><th>Id Companie</th><th>Id Regiune</th><th>Adresa Sucursala</th><th>Telefon Sucursala</th></tr>\n";

while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
       print '<td>'.($item !== null ? htmlentities($item, ENT_QUOTES) : '&nbsp').'</td>';
   }
   print '</tr>';
}
print '</table>';-->

<table border="1">



<!--tr><th><a href ="companii_id.php?">Ascendent</a></th><th><a href="companii_nume.php?">Ascendent</a></th><th><a href="companii_telefon.php?">Ascendent</a></th></tr>
<tr><th><a href="companii2_id.php?">Descendent</a></th><th><a href="companii2_nume.php?">Descendent</a></th><th><a href="companii2_telefon.php?">Descendent</a></th></tr-->
<tr>

<tr><th><a href ="sucursale_id.php?">Ascendent</a></th><th><a href="sucursale_idc.php?">Ascendent</a></th><th><a href ="sucursale_idr.php?">Ascendent</a></th><th><a href ="sucursale_adresa.php?">Ascendent</a></th><th><a href ="sucursale_telefon.php?">Ascendent</a></th></tr>
<tr><th><a href ="sucursale2_id.php?">Descendent</a></th><th><a href="sucursale2_idc.php?">Descendent</a></th><th><a href ="sucursale2_idr.php?">Descendent</a></th><th><a href ="sucursale2_adresa.php?">Descendent</a></th><th><a href ="sucursale2_telefon.php?">Descendent</a></th></tr>
<tr><th>Id Sucursala</th><th>Id Companie</th><th>Id Regiune</th><th>Adresa Sucursala</th><th>Telefon Sucursala</th>
	<th>Stergere</th> 
	<th>Modificare</th></tr>

<?php 
foreach($results as $linie) { ?>
   <tr>
  <?php foreach ($linie as $coloana) { ?>
       <td> <?php echo $coloana; ?> </td> <!--'.($item !== null ? htmlentities($item, ENT_QUOTES) : '&nbsp').' -->
  <?php } ?>

		<td><a href="stergeIntrare.php?tabel=sucursale&id_sucursala=<?php echo $linie["ID_SUCURSALA"]?>"> Sterge</a></td>
		<td><a href="editeaza.php?tabel=sucursale&id_sucursala=<?php echo $linie["ID_SUCURSALA"]?>"> Modifica</a><td>

  </tr>


<?php } ?>

</table>

 <a class="backHome" href="index.php" style=" text-decoration:none;user-select:none;padding:10px 20px; text-align:center;position:fixed;bottom:10px;left:10px; background:royalblue;color: white; font-family: monospace;">Home</a>
</body>
</html>