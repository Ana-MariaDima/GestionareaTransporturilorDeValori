<html>
<head><title>TABEL REGIUNI</title></head>
<style type="text/css">
table{
	border-collapse: collapse;
	width: 100%;
	color: #FF69B4;
	font-family: monospace;
	font-size: 25px;
	text-align: left;
	}

th{
	background-color: #DDA0DD;
	color: #4B0082;
	}
tr:nth-child(even){background-color: #F8F8FF}
</style>
<body>
    <?php
    $conn=oci_connect("transport2","transport","//localhost/orcl");

   
$query = 'select id_sucursala, id_regiune,nume_regiune
from sucursale join regiuni using(id_regiune)
group by nume_regiune, id_sucursala,id_regiune
having(id_regiune=1)';



$stid = oci_parse($conn, $query);
$r = oci_execute($stid);

// Fetch each row in an associative array
print '<table border="1">';
print'<tr><th><a href ="group_ids.php?">Ascendent</a></th><th><a href="group_idr.php?">Ascendent</a></th><th><a href="group_denumire.php?">Ascendent</a></th></tr>';
print'<tr><th><a href ="group2_ids.php?">Descendent</a></th><th><a href="group2_idr.php?">Descendent</a></th><th><a href="group_denumire.php?">Descendent</a></th></tr>';

print"<tr><th>Id Sucursala</th><th>Id Regiune</th><th>Denumire Regiune</th></tr>\n";


while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
       print '<td>'.($item !== null ? htmlentities($item, ENT_QUOTES) : '&nbsp').'</td>';
   }
   print '</tr>';
}
print '</table>';



oci_close($conn);
?>
 <a class="backHome" href="index.php" style=" text-decoration:none;user-select:none;padding:10px 20px; text-align:center;position:fixed;bottom:10px;left:10px; background:royalblue;color: white; font-family: monospace;">Home</a>
</body>
</html>