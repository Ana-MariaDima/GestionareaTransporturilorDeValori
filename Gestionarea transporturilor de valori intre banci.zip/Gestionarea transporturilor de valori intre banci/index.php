<html>

<body>
    <!--h2 style="text-align: center;margin-top:50px;">Proiect Baze de Date</h2-->
	<h2 style="text-align: center;margin-top:50px;text-transform:uppercase;font-weight:200;font-style:italic;">Firma de Transport Valori</h2>

    <div class="grid">
        <a href="companii.php" class="blocks"> COMPANII</a>
        <a href="sucursale.php" class="blocks"> SUCURSALE </a>
        <a href="regiuni.php" class="blocks"> REGIUNI </a>
        <a href="curse.php" class="blocks"> CURSE </a>
        <a href="masini.php" class="blocks"> MASINI </a>
        <a href="tipuri_masini.php" class="blocks"> TIPURI MASINI</a>
        <a href="angajati.php" class="blocks"> ANGAJATI </a>
        <a href="grila_salariala.php" class="blocks"> GRILA SALARIALA</a>
        <a href="join+where.php" class="blocks"> JOIN+WHERE </a>
        <a href="group+having.php" class="blocks"> GROUP+HAVING </a>
    </div>

      <style>
      .body{
          background:#f2f2f3;
      }
      
          .blocks{
              background:#7B68EE;
          }
      .grid {
          width:50%;
          margin:0 auto;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            grid-gap: .5rem;
            padding: .5rem;
            grid-auto-rows: minmax(100px, auto);
            background:white;
            box-shadow:0px 10px 50px -20px black;
}
 .blocks{
     font-family: monospace;
     text-decoration: none;;
     user-select: none;
     cursor: pointer;
    margin:10px;
    transition:.2s ease-in-out;
    color:white;
    text-align: center;
    padding:50px 0;
    
}
 .blocks:hover{
         transform:scale(1.1);
    }
      </style>


      <a class="backHome" href="/" style=" text-decoration:none;user-select:none;padding:10px 20px; text-align:center;position:fixed;bottom:10px;left:10px; background:royalblue;color: white; font-family: monospace;">Home</a>
     
</body>
</html>