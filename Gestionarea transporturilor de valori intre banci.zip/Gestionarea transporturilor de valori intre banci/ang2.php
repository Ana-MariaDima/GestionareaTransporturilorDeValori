<html>
<head><title>TABEL ANGAJATI</title></head>
<style type="text/css">
table{
	border-collapse: collapse;
	width: 100%;
	color: #FF69B4;
	font-family: monospace;
	font-size: 25px;
	text-align: left;
	}

th{
	background-color: #DDA0DD;
	color: #4B0082;
	}
tr:nth-child(even){background-color: #F8F8FF}
</style>
<body>
    <?php
    $conn=oci_connect("transport2","transport","//localhost/orcl");
   
$query = 'select *from angajati ';
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);

// Fetch each row in an associative array
print '<table border="1">';
print'<tr><th><a href ="angajati_id.php?">Ascendent</a></th><th><a href="angajati_nivel.php?">Ascendent</a></th><th><a href="angajati_nume.php?">Ascendent</a></th><th><a href="angajati_prenume.php?">Ascendent</a></th><th><a href="angajati_telefon.php?">Ascendent</a></th><th><a href="angajati_datanasterii.php?">Ascendent</a></th><th><a href="angajati_dataangajarii.php?">Ascendent</a></th></tr>';
print'<tr><th><a href ="angajati2_id.php?">Descendent</a></th><th><a href="angajati2_nivel.php?">Descendent</a></th><th><a href="angajati2_nume.php?">Descendent</a></th><th><a href="angajati2_prenume.php?">Descendent</a></th><th><a href="angajati2_telefon.php?">Descendent</a></th><th><a href="angajati2_datanasterii.php?">Descendent</a></th><th><a href="angajati2_dataangajarii.php?">Descendent</a></th></tr>';
print"<tr><th>Id Angajat</th><th>Nivel Salarial</th><th>Nume</th><th>Prenume</th><th>Telefon</th><th>Data Nasterii</th><th>Data Angajarii</th></tr>\n";


while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
  ?>

<tr>

<td><div align="center"><?php echo $row["CUSTOMERID"];?></div></td>

<td><?php echo $row["NAME"];?></td>

<td><?php echo $row["EMAIL"];?></td>

<td><div align="center"><?php echo $row["COUNTRYCODE"];?></div></td>

<td align="right"><?php echo $row["BUDGET"];?></td>

<td align="right"><?php echo $row["USED"];?></td>

<td align="center"><a href="phpOracleDeleteRecord.php?CusID=<?php echo $row["CUSTOMERID"];?>">Delete</a></td>

</tr>

<?php
	

   }
   print '</tr>';





oci_close($conn);
?>
   <a class="backHome" href="index.php" style=" text-decoration:none;user-select:none;padding:10px 20px; text-align:center;position:fixed;bottom:10px;left:10px; background:royalblue;color: white; font-family: monospace;">Home</a>
 
</body>
</html>