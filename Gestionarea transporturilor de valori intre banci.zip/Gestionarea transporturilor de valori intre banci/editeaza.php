
<?php


$tabel = $_GET["tabel"];
$coloana = $_GET[array_keys($_GET)[1]];
$nume_coloana = array_keys($_GET)[1];

if(isset($tabel) && isset($coloana) && isset($nume_coloana)){
$conn=oci_connect("transport2","transport","//localhost/orcl");
    
    if(isset($_POST["salvare"])){
        
        $query = "UPDATE $tabel SET ";
        $index = 0;
        foreach($_POST as $key=>$value){
            if($key != 'salvare'){
                if($index != count($_POST)-1)
                 $query = $query." $key='".$value."',";
                 else
                 $query = $query." $key='".$value."' ";
            }
           $index++;
        }

        $query = $query." WHERE ".$nume_coloana." = '".$coloana."'";
       
        $stid = oci_parse($conn, $query);
        $r = oci_execute($stid);
        oci_close($conn);

    }

$tabel = strtoupper($tabel);
$query = "SELECT  column_name FROM USER_TAB_COLUMNS WHERE table_name = '$tabel'";


$stid = oci_parse($conn, $query);
$r = oci_execute($stid);
$coloane = array();
$buffer = [];
while($buffer = oci_fetch_array ($stid, OCI_RETURN_NULLS+OCI_ASSOC)){
	$coloane[] = $buffer;
}

$query = "SELECT  * FROM $tabel WHERE $nume_coloana = '$coloana'";
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);
$valori = array();
$buffer = [];
while($buffer = oci_fetch_array ($stid, OCI_RETURN_NULLS+OCI_ASSOC)){
	$valori[] = $buffer;
}
$valori = $valori[0];



oci_close($conn);


}
?>


<html>

<body>
    <!--h2 style="text-align: center;margin-top:50px;">Proiect Baze de Date</h2-->
	<h2 style="text-align: center;margin-top:50px;text-transform:uppercase;font-weight:200;font-style:italic;">Firma de Transport Valori</h2>

    <form class="grid" action="/editeaza.php?tabel=<?php echo $tabel;?>&<?php echo $nume_coloana.'='.$coloana;?>" method="post">
        <input type="hidden" name="salvare" value="1">
        
        <?php $i = 0; foreach($coloane as $coloana) { ?>
        
        <div class="row"> 
            <label> <?php echo $coloana["COLUMN_NAME"] ?>  </label>
            <input type="text" <?php echo $i==0?"disabled":""; ?> name="<?php echo $coloana["COLUMN_NAME"]; ?>" value="<?php echo $valori[$coloana["COLUMN_NAME"]]; ?>">
         </div>
        <?php $i++; } ?>
       
         <div class="row"> 
            <input type="submit" class="salveaza" value="Salveaza" style="float:right;" >
         </div>
    </form>

      <style>
      .salveaza{
          border:none;
          background:white;
          border:1px solid black;
          padding:10px;
      }
      .body{
          background:#f2f2f3;
      }
      
          .blocks{
              background:#7B68EE;
          }
      .grid {
          width:50%;
          margin:0 auto;
            display: block;
            /* grid-template-columns: repeat(3, 1fr);
            grid-gap: .5rem; */
            padding: 30px;
            padding-bottom:50px;
            /* grid-auto-rows: minmax(100px, auto); */
            background:white;
            box-shadow:0px 10px 50px -20px black;
}

 .row{
     display:block;
     padding-bottom: 5px;
 }
 .row > *{
     display:block;
 }
 .blocks{
     font-family: monospace;
     text-decoration: none;;
     user-select: none;
     cursor: pointer;
    margin:10px;
    transition:.2s ease-in-out;
    color:white;
    text-align: center;
    padding:50px 0;
}
input{
    border:1px solid none;
}
 .blocks:hover{
         transform:scale(1.1);
    }


      </style>


      <a class="backHome" href="/" style=" text-decoration:none;user-select:none;padding:10px 20px; text-align:center;position:fixed;bottom:10px;left:10px; background:royalblue;color: white; font-family: monospace;">Home</a>
     
</body>
</html>