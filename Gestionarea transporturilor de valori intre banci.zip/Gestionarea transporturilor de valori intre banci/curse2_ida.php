

<?php

$conn=oci_connect("transport2","transport","//localhost/orcl");
   
$query = 'select *from curse order by id_angajat desc';
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);
$results = array();
$buffer= [];
while($buffer = oci_fetch_array ($stid, OCI_RETURN_NULLS+OCI_ASSOC)){
	$results[] = $buffer;
}

oci_close($conn);
?>

<html>
<head><title>TABEL CURSE</title></head>
<style type="text/css">
table{
	border-collapse: collapse;
	width: 100%;
	color: #FF69B4;
	font-family: monospace;
	font-size: 25px;
	text-align: left;

	box-shadow: 0px 10px 50px -20px black;
    transform: scale(0.9);
    
	}

th{
	background-color: #DDA0DD;
	color: #4B0082;
	}
tr:nth-child(even){background-color: #F8F8FF}
</style>
<body>


<table border="1">




<tr>
<tr><th><a href ="curse_data.php?">Ascendent</a></th><th><a href="curse_nr.php?">Ascendent</a></th><th><a href="curse_ids.php?">Ascendent</a></th><th><a href="curse_ida.php?">Ascendent</a></th><th><a href="curse_se.php?">Ascendent</a></th><th><a href="curse_suma.php?">Ascendent</a></th><th><a href="curse_plicuri.php?">Ascendent</a></th></tr>
<tr><th><a href ="curse2_data.php?">Descendent</a></th><th><a href="curse2_nr.php?">Descendent</a></th><th><a href="curse2_ids.php?">Descendent</a></th><th><a href="curse2_ida.php?">Descendent</a></th><th><a href="curse2_sd.php?">Descendent</a></th><th><a href="curse2_suma.php?">Descendent</a></th><th><a href="curse2_plicuri.php?">Descendent</a></th></tr>
<tr><th>Data Cursa</th><th>Numar Masina</th>
<th>Id Sucursala</th><th>ID_angajat</th><th>Sucursala Destinatie</th><th>Suma Transportata</th><th>Nr Plicuri</th>
	<th>Stergere</th> 
	<th>Modificare</th>
	</tr>

<?php 
foreach($results as $linie) { ?>
   <tr>
  <?php foreach ($linie as $coloana) { ?>
       <td> <?php echo $coloana; ?> </td> <!--'.($item !== null ? htmlentities($item, ENT_QUOTES) : '&nbsp').' -->
  <?php } ?>

		<td><a href="stergeIntrareA.php?tabel=curse&id_sucursala=<?php echo $linie["ID_SUCURSALA"]?>&data_cursa=<?php echo $linie["DATA_CURSA"];?>"> Sterge</a></td>
		<td><a href="editeazaAsociativ.php?tabel=curse&id_sucursala=<?php echo $linie["ID_SUCURSALA"]?>&data_cursa=<?php echo $linie["DATA_CURSA"];?>"> Modifica</a><td>

  </tr>


<?php } ?>

</table>
 <a class="backHome" href="index.php" style=" text-decoration:none;user-select:none;padding:10px 20px; text-align:center;position:fixed;bottom:10px;left:10px; background:royalblue;color: white; font-family: monospace;">Home</a>
</body>
</html>