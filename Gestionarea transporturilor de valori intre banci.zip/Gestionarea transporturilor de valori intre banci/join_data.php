<html>
<head><title>TABEL REGIUNI</title></head>
<style type="text/css">
table{
	border-collapse: collapse;
	width: 100%;
	color: #FF69B4;
	font-family: monospace;
	font-size: 25px;
	text-align: left;
	}

th{
	background-color: #DDA0DD;
	color: #4B0082;
	}
tr:nth-child(even){background-color: #F8F8FF}
</style>
<body>
    <?php
    $conn=oci_connect("transport2","transport","//localhost/orcl");

   
$query = 'select ID_ANGAJAT, NUME, PRENUME, denumire, ID_COMPANIE,DATA_CURSA, ID_SUCURSALA,SUCURSALA_DESTINATIE
from SUCURSALE join COMPANII using(ID_COMPANIE)
JOIN CURSE USING(ID_SUCURSALA)
JOIN ANGAJATI USING(ID_ANGAJAT)
JOIN GRILA_SALARIALA  USING(NIVEL_SALARIAL)
where id_angajat=7 AND ID_COMPANIE=2
order by data_cursa';



$stid = oci_parse($conn, $query);
$r = oci_execute($stid);

// Fetch each row in an associative array
print '<table border="1">';
print'<tr><th><a href ="join_id.php?">Ascendent</a></th><th><a href="join_nume.php?">Ascendent</a></th><th><a href="join_prenume.php?">Ascendent</a></th><th><a href="join.denumire.php?">Ascendent</a></th><th><a href="join_companie.php?">Ascendent</a></th><th><a href="join_data.php?">Ascendent</a></th><th><a href ="join_ids.php?">Ascendent</a></th><th><a href ="join_sd.php?">Ascendent</a></th></tr>';
print'<tr><th><a href ="join2_id.php?">Descendent</a></th><th><a href="join2_nume.php?">Descendent</a></th><th><a href="join2_prenume.php?">Descendent</a></th><th><a href="join2.denumire.php?">Descendent</a></th><th><a href="join2_companie.php?">Descendent</a></th><th><a href="join2_data.php?">Descendent</a></th><th><a href ="join2_ids.php?">Descendent</a></th><th><a href ="join2_sd.php?">Descendent</a></th></tr>';

print"<tr><th>Id Angajat</th><th>Nume</th><th>Prenume</th><th>Denumire_Nivel_salarial</th><th>Id Companie</th><th>Data Cursa</th><th>Sucursala Pornire</th><th>Sucursala Destinatie</th></tr>\n";


while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
       print '<td>'.($item !== null ? htmlentities($item, ENT_QUOTES) : '&nbsp').'</td>';
   }
   print '</tr>';
}
print '</table>';



oci_close($conn);
?>
 <a class="backHome" href="index.php" style=" text-decoration:none;user-select:none;padding:10px 20px; text-align:center;position:fixed;bottom:10px;left:10px; background:royalblue;color: white; font-family: monospace;">Home</a>
</body>
</html>