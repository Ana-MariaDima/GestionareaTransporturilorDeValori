<?php

$tabel = $_GET["tabel"];
$coloana = $_GET[array_keys($_GET)[1]];
$nume_coloana = array_keys($_GET)[1];

$coloana2 = $_GET[array_keys($_GET)[2]];
$nume_coloana2 = array_keys($_GET)[2];

if(isset($tabel) && isset($coloana) && isset($nume_coloana)){
$conn=oci_connect("transport2","transport","//localhost/orcl");
   
$query = "delete from $tabel where $nume_coloana = '$coloana' and $nume_coloana2 = '$coloana2'";
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);
}

header("Location: ".$_SERVER['HTTP_REFERER']);

?>