<?php

$conn=oci_connect("transport2","transport","//localhost/orcl");
   
$query = 'select *from angajati order by nume';
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);
$results = array();
$buffer= [];
while($buffer = oci_fetch_array ($stid, OCI_RETURN_NULLS+OCI_ASSOC)){
	$results[] = $buffer;
}

oci_close($conn);
?>
<html>
<head><title>TABEL ANGAJATI</title></head>
<style type="text/css">
table{
	border-collapse: collapse;
	width: 100%;
	color: #FF69B4;
	font-family: monospace;
	font-size: 25px;
	text-align: left;
	
	box-shadow: 0px 10px 50px -20px black;
    transform: scale(0.9);
	}

th{
	background-color: #DDA0DD;
	color: #4B0082;
	}
tr:nth-child(even){background-color: #F8F8FF}
</style>
<body>

<table border="1">



<tr>
<tr><th><a href ="angajati_id.php?">Ascendent</a></th><th><a href="angajati_nivel.php?">Ascendent</a></th><th><a href="angajati_nume.php?">Ascendent</a></th><th><a href="angajati_prenume.php?">Ascendent</a></th><th><a href="angajati_telefon.php?">Ascendent</a></th><th><a href="angajati_datanasterii.php?">Ascendent</a></th><th><a href="angajati_dataangajarii.php?">Ascendent</a></th></tr>
<tr><th><a href ="angajati2_id.php?">Descendent</a></th><th><a href="angajati2_nivel.php?">Descendent</a></th><th><a href="angajati2_nume.php?">Descendent</a></th><th><a href="angajati2_prenume.php?">Descendent</a></th><th><a href="angajati2_telefon.php?">Descendent</a></th><th><a href="angajati2_datanasterii.php?">Descendent</a></th><th><a href="angajati2_dataangajarii.php?">Descendent</a></th></tr>
<tr><th>Id Angajat</th><th>Nivel Salarial</th><th>Nume</th><th>Prenume</th><th>Telefon</th><th>Data Nasterii</th><th>Data Angajarii</th>

	<th>Stergere</th> 
	<th>Modificare</th></tr>

<?php 
foreach($results as $linie) { ?>
   <tr>
  <?php foreach ($linie as $coloana) { ?>
       <td> <?php echo $coloana; ?> </td> <!--'.($item !== null ? htmlentities($item, ENT_QUOTES) : '&nbsp').' -->
  <?php } ?>

		<td><a href="stergeIntrare.php?tabel=angajati&id_angajat=<?php echo $linie["ID_ANGAJAT"]?>"> Sterge</a></td>
		<td><a href="editeaza.php?tabel=angajati&id_angajat=<?php echo $linie["ID_ANGAJAT"]?>"> Modifica</a><td>

  </tr>


<?php } ?>

</table>

   <a class="backHome" href="index.php" style=" text-decoration:none;user-select:none;padding:10px 20px; text-align:center;position:fixed;bottom:10px;left:10px; background:royalblue;color: white; font-family: monospace;">Home</a>
 
</body>
</html>